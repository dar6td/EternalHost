require('dotenv').config();
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const root = path.join(__dirname, '..');
const dataDir = path.resolve(root, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const dbFile = process.env.DATABASE_FILE ? path.resolve(root, process.env.DATABASE_FILE) : path.join(dataDir, 'eternalhost.sqlite');
fs.mkdirSync(path.dirname(dbFile), { recursive: true });
const db = new sqlite3.Database(dbFile);
const MIN_RAM = Number(process.env.MIN_SERVER_RAM_GB || 6);
const MAX_RAM = Number(process.env.MAX_SERVER_RAM_GB || 128);
const TOTAL_RAM = Number(process.env.MAX_TOTAL_RAM_GB || 128);
const suffix = String(process.env.SERVER_DOMAIN_SUFFIX || 'fun').toLowerCase().replace(/^\.+|\.+$/g, '');

function run(sql, params = []) { return new Promise((resolve, reject) => db.run(sql, params, function (err) { err ? reject(err) : resolve(this); })); }
function get(sql, params = []) { return new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row))); }
function all(sql, params = []) { return new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows))); }
function initDb() {
  return new Promise((resolve, reject) => db.serialize(() => {
    db.run('PRAGMA foreign_keys = ON');
    db.run(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`);
    db.run(`CREATE TABLE IF NOT EXISTS servers (id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, edition TEXT NOT NULL, software TEXT NOT NULL, version TEXT NOT NULL, ram_gb INTEGER NOT NULL, port INTEGER NOT NULL UNIQUE, status TEXT NOT NULL DEFAULT 'stopped', container_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE)`);
    db.run('CREATE INDEX IF NOT EXISTS idx_servers_user ON servers(user_id)', err => err ? reject(err) : resolve());
  }));
}
function slugify(v) { return String(v || '').normalize('NFKD').toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40); }
function validVersion(v) { return /^\d{1,2}\.\d{1,2}(?:\.\d{1,2})?$/.test(String(v)); }
function hostFor(slug) { return `play.${slug}.${suffix}`; }
function requireAuth(req, res, next) { if (!req.session.user) return res.status(401).json({ error: 'Please log in first.' }); next(); }
function safeUser(u) { return { id: u.id, username: u.username, email: u.email }; }
function docker(args) {
  return new Promise((resolve, reject) => {
    const child = spawn('docker', args, { stdio: ['ignore', 'pipe', 'pipe'], shell: false });
    let out = '', err = '';
    child.stdout.on('data', d => out += d); child.stderr.on('data', d => err += d);
    child.on('error', reject); child.on('close', code => code === 0 ? resolve(out.trim()) : reject(new Error(err.trim() || `Docker exited with ${code}`)));
  });
}
async function provisionDns(slug, port) {
  const token = process.env.CLOUDFLARE_API_TOKEN, zone = process.env.CLOUDFLARE_ZONE_ID, ip = process.env.PUBLIC_HOST_IP;
  if (!token || !zone || !ip) return { configured: false, message: 'DNS not provisioned: configure Cloudflare credentials, zone ID, and PUBLIC_HOST_IP.' };
  const domain = hostFor(slug);
  const api = `https://api.cloudflare.com/client/v4/zones/${encodeURIComponent(zone)}/dns_records`;
  async function create(record) {
    const r = await fetch(api, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(record) });
    const body = await r.json().catch(() => ({}));
    if (!r.ok || !body.success) throw new Error(`DNS provider rejected ${record.type} record: ${JSON.stringify(body.errors || body)}`);
    return body.result;
  }
  await create({ type: 'A', name: domain, content: ip, ttl: 120, proxied: false });
  // SRV allows a hostname to reach a server on a non-default port. DNS provider support must be enabled for this zone.
  await create({ type: 'SRV', name: `_minecraft._tcp.${domain}`, data: { service: '_minecraft', proto: '_tcp', name: domain, priority: 0, weight: 5, port, target: domain }, ttl: 120 });
  return { configured: true, message: `DNS records requested for ${domain}` };
}
async function provisionContainer(server) {
  if (process.env.ENABLE_DOCKER_PROVISIONING !== 'true') return { enabled: false, message: 'Docker provisioning is disabled. Review README and enable it only on a secured host.' };
  if (server.edition !== 'Java') throw new Error('This starter currently provisions Java servers only.');
  const image = 'itzg/minecraft-server:java21';
  const args = ['run', '-d', '--name', `eternalhost-${server.id}`, '--restart', 'unless-stopped', '--memory', `${server.ram_gb}g`, '--memory-swap', `${server.ram_gb}g`, '-p', `${server.port}:25565`, '-e', 'EULA=TRUE', '-e', `TYPE=${server.software.toUpperCase()}`, '-e', `VERSION=${server.version}`, '-e', `MEMORY=${Math.max(2, server.ram_gb - 1)}G`, '-v', `${path.join(dataDir, 'servers', server.id)}:/data`, image];
  fs.mkdirSync(path.join(dataDir, 'servers', server.id), { recursive: true });
  const containerId = await docker(args);
  await run('UPDATE servers SET container_id = ?, status = ? WHERE id = ?', [containerId.slice(0, 12), 'starting', server.id]);
  return { enabled: true, containerId: containerId.slice(0, 12) };
}

app.disable('x-powered-by');
if (process.env.TRUST_PROXY === 'true') app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"], connectSrc: ["'self'"] } } }));
app.use(express.json({ limit: '32kb' }));
app.use(express.urlencoded({ extended: false, limit: '32kb' }));
app.use(session({ store: new SQLiteStore({ db: 'sessions.sqlite', dir: dataDir }), name: 'eternalhost.sid', secret: process.env.SESSION_SECRET || 'development-only-change-me', resave: false, saveUninitialized: false, cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 12 } }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(root, 'public')));

app.get('/api/config', (req, res) => res.json({ hostingName: 'EternalHost', minRamGb: MIN_RAM, maxRamGb: MAX_RAM, domainSuffix: suffix, software: ['Paper', 'Vanilla', 'Purpur', 'Fabric', 'Forge', 'NeoForge'], editions: ['Java', 'Bedrock'], note: 'Minecraft version availability is validated by the actual server image at startup.' }));
app.get('/api/me', (req, res) => res.json({ user: req.session.user || null }));
app.post('/api/auth/register', async (req, res) => {
  try {
    const username = String(req.body.username || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) return res.status(400).json({ error: 'Username must be 3–24 letters, numbers, or underscores.' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return res.status(400).json({ error: 'Enter a valid email address.' });
    if (password.length < 12 || password.length > 128) return res.status(400).json({ error: 'Password must be 12–128 characters.' });
    const hash = await bcrypt.hash(password, 12);
    const result = await run('INSERT INTO users (username,email,password_hash) VALUES (?,?,?)', [username, email, hash]);
    req.session.regenerate(err => { if (err) return res.status(500).json({ error: 'Could not start session.' }); req.session.user = { id: result.lastID, username, email }; res.status(201).json({ user: req.session.user }); });
  } catch (e) { res.status(409).json({ error: /UNIQUE/.test(e.message) ? 'Username or email is already registered.' : 'Registration failed.' }); }
});
app.post('/api/auth/login', async (req, res) => {
  try {
    const identity = String(req.body.identity || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const user = await get('SELECT * FROM users WHERE lower(username)=? OR email=?', [identity, identity]);
    if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'Invalid login details.' });
    req.session.regenerate(err => { if (err) return res.status(500).json({ error: 'Could not start session.' }); req.session.user = safeUser(user); res.json({ user: req.session.user }); });
  } catch { res.status(500).json({ error: 'Login failed.' }); }
});
app.post('/api/auth/logout', (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get('/api/servers', requireAuth, async (req, res) => { try { const servers = await all('SELECT id,name,slug,edition,software,version,ram_gb,port,status,created_at FROM servers WHERE user_id=? ORDER BY created_at DESC', [req.session.user.id]); res.json({ servers: servers.map(s => ({ ...s, address: hostFor(s.slug) })) }); } catch { res.status(500).json({ error: 'Could not load servers.' }); } });
app.post('/api/servers', requireAuth, async (req, res) => {
  try {
    const name = String(req.body.name || '').trim();
    const slug = slugify(name);
    const edition = String(req.body.edition || 'Java');
    const software = String(req.body.software || 'Paper');
    const version = String(req.body.version || '');
    const ram = Number(req.body.ramGb);
    if (name.length < 3 || name.length > 40 || !slug || slug.length < 3) return res.status(400).json({ error: 'Server name must produce a 3–40 character DNS-safe name.' });
    if (!['Java', 'Bedrock'].includes(edition)) return res.status(400).json({ error: 'Unsupported edition.' });
    if (!['Paper','Vanilla','Purpur','Fabric','Forge','NeoForge'].includes(software)) return res.status(400).json({ error: 'Unsupported software.' });
    if (edition === 'Bedrock' && software !== 'Vanilla') return res.status(400).json({ error: 'This starter supports Bedrock only with Vanilla selected.' });
    if (edition === 'Java' && !['Paper','Vanilla','Purpur','Fabric','Forge','NeoForge'].includes(software)) return res.status(400).json({ error: 'Unsupported Java software.' });
    if (!validVersion(version)) return res.status(400).json({ error: 'Version must look like 1.21.4. Actual availability is checked when the server starts.' });
    if (!Number.isInteger(ram) || ram < MIN_RAM || ram > MAX_RAM || ram > 128) return res.status(400).json({ error: `RAM must be a whole number between ${MIN_RAM} and ${Math.min(MAX_RAM,128)} GB.` });
    const used = await get('SELECT COALESCE(SUM(ram_gb),0) AS total FROM servers WHERE status != "deleted"');
    if (used.total + ram > TOTAL_RAM) return res.status(409).json({ error: `Resource budget exceeded. ${used.total} GB is allocated and the configured total budget is ${TOTAL_RAM} GB.` });
    if (await get('SELECT id FROM servers WHERE slug=?', [slug])) return res.status(409).json({ error: 'That server address is already in use. Choose a different name.' });
    const portRow = await get('SELECT COALESCE(MAX(port),25564)+1 AS port FROM servers');
    const port = Math.min(65535, Math.max(25565, portRow.port));
    if (portRow.port > 65535) return res.status(409).json({ error: 'No available ports.' });
    const id = require('crypto').randomUUID();
    await run('INSERT INTO servers (id,user_id,name,slug,edition,software,version,ram_gb,port,status) VALUES (?,?,?,?,?,?,?,?,?,?)', [id, req.session.user.id, name, slug, edition, software, version, ram, port, 'stopped']);
    const server = await get('SELECT * FROM servers WHERE id=?', [id]);
    let provisioning = { enabled: false, message: 'Server configuration saved; runtime provisioning is disabled.' };
    try { provisioning = await provisionContainer(server); } catch (e) { provisioning = { enabled: true, error: e.message }; await run('UPDATE servers SET status="error" WHERE id=?', [id]); }
    let dns = { configured: false, message: 'DNS credentials not configured.' };
    try { dns = await provisionDns(slug, port); } catch (e) { dns = { configured: false, error: e.message }; }
    res.status(201).json({ server: { id, name, slug, edition, software, version, ramGb: ram, port, address: hostFor(slug), status: (await get('SELECT status FROM servers WHERE id=?',[id])).status }, provisioning, dns });
  } catch (e) { res.status(500).json({ error: 'Could not create server configuration.' }); }
});
app.post('/api/servers/:id/action', requireAuth, async (req, res) => {
  try {
    const s = await get('SELECT * FROM servers WHERE id=? AND user_id=?', [req.params.id, req.session.user.id]);
    if (!s) return res.status(404).json({ error: 'Server not found.' });
    if (process.env.ENABLE_DOCKER_PROVISIONING !== 'true') return res.status(409).json({ error: 'Runtime actions are disabled until Docker provisioning is enabled by the administrator.' });
    if (!s.container_id) return res.status(409).json({ error: 'No container exists for this server yet.' });
    const action = String(req.body.action || '');
    if (!['start','stop','restart'].includes(action)) return res.status(400).json({ error: 'Unsupported action.' });
    await docker([action, `eternalhost-${s.id}`]);
    await run('UPDATE servers SET status=? WHERE id=?', [action === 'stop' ? 'stopped' : 'running', s.id]);
    res.json({ ok: true, status: action === 'stop' ? 'stopped' : 'running' });
  } catch (e) { res.status(500).json({ error: 'Server action failed.' }); }
});
app.get('/api/servers/:id/console', requireAuth, async (req, res) => {
  const s = await get('SELECT * FROM servers WHERE id=? AND user_id=?', [req.params.id, req.session.user.id]);
  if (!s) return res.status(404).json({ error: 'Server not found.' });
  if (process.env.ENABLE_DOCKER_PROVISIONING !== 'true' || !s.container_id) return res.json({ lines: ['Console unavailable: runtime provisioning is not enabled or this server has no container.'] });
  try { const output = await docker(['logs','--tail','100',`eternalhost-${s.id}`]); res.json({ lines: output.split('\n').slice(-100) }); } catch { res.status(500).json({ error: 'Could not read console logs.' }); }
});
app.get('*', (req, res) => res.sendFile(path.join(root, 'public', 'index.html')));
initDb().then(() => app.listen(PORT, '0.0.0.0', () => console.log(`EternalHost panel listening on port ${PORT}`))).catch(err => { console.error('Database initialization failed:', err); process.exit(1); });
