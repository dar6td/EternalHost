# EternalHost Panel (starter)

A Node.js 20+ starter for a Minecraft hosting control panel branded **EternalHost**. Includes registration/login, SQLite persistence, session cookies, server configuration wizard, server name-to-hostname preview, RAM limits, server list, basic actions/console logs when Docker provisioning is enabled, and optional Cloudflare DNS A/SRV record provisioning.

## Important limitations

This is a starter, not a production-ready clone of AstroWax or a fully managed commercial hosting platform. It does **not** yet implement live WebSocket console command input, a file manager, plugin/mod/datapack/resource-pack installers, backups, billing, a full software/version changer, Bedrock container provisioning, admin roles, quotas per user, or abuse monitoring. Do not expose it publicly until security review, CSRF protection, admin controls, logging, and deployment hardening are complete.

Minecraft version `26.2` is accepted only as a syntactically valid version string here. The selected Docker image may not support it; validate actual release availability before provisioning. RAM values are validated against the configured total budget, but `MAX_TOTAL_RAM_GB=128` is only an administrative budget. It does not create physical memory. Set it no higher than the host can safely provide.

## Run locally

1. Install Node.js 20 or newer and npm.
2. Copy `.env.example` to `.env` and set a long random `SESSION_SECRET`.
3. Set `MAX_TOTAL_RAM_GB` to the actual safe memory budget. The default 128 GB is a ceiling only.
4. Install dependencies and start:

   ```bash
   npm install
   npm start
   ```

5. Open `http://localhost:3000`.

## Real DNS setup

Use a domain you own. Configure `SERVER_DOMAIN_SUFFIX` to the chosen suffix (for example, `fun`) and ensure each generated name is a valid hostname under a zone managed by your DNS provider. For Cloudflare, set `CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ZONE_ID`, and `PUBLIC_HOST_IP`. The token needs permission to edit DNS records for that zone. This code requests an A record and Minecraft SRV record. Check the resulting records in your provider dashboard and test resolution before sharing the address. DNS cannot be provisioned for a domain you do not control.

## Docker provisioning (optional, use caution)

Docker provisioning is disabled by default. Before enabling `ENABLE_DOCKER_PROVISIONING=true`, deploy on a dedicated, secured Linux host, review the container image and generated Docker arguments, configure firewall/port ranges, backups, quotas, and monitoring. Membership of the Docker socket is effectively root-equivalent. Never mount the Docker socket into an untrusted application container. The current implementation assumes the Docker CLI is installed on the host and runs commands as the panel's OS user.

## Configuration values

- `MIN_SERVER_RAM_GB`: minimum per-server RAM (default 6)
- `MAX_SERVER_RAM_GB`: maximum per-server RAM (default 128)
- `MAX_TOTAL_RAM_GB`: aggregate RAM budget across configured servers (default 128)
- `SERVER_DOMAIN_SUFFIX`: DNS suffix (default `fun`)
- `ENABLE_DOCKER_PROVISIONING`: enable real container actions only after review
- `PUBLIC_HOST_IP`, `CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ZONE_ID`: optional DNS integration

## Notes

The initial UI defaults to `test618`, Paper, and version `26.2` as a demonstration matching the requested example. Creating a server only saves configuration while Docker provisioning is disabled. DNS provisioning requires valid provider credentials. Do not put secrets in source control.
